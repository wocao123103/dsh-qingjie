# 青衿科研 · Qingjin Research

> 把一句模糊的想法，变成论文形状的计划。
> 面向本科生（尤其大一）：先给骨架，再给英文表述，最后给诊断——成文仍由你自己完成。

一个 DeepSeek Harness（DSH）插件。安装后在对话里直接说「帮我列一篇关于 X 的论文骨架」「帮我检查这段引言」，模型会调用三个工具。

## 三个工具

| 工具 | 作用 | 典型输入 |
|---|---|---|
| `qingjin_outline` | 生成章节骨架：每节的目标、时态、篇幅预算、结构动作（IMRaD / CARS / C-C-C）、自查清单、起手句 | `kind=research`（全文）、`kind=proposal`（大创申报书）、或单节 `abstract/introduction/methods/results/discussion/conclusion` |
| `qingjin_template` | 生成**可填写的成稿模板**：`format=md` 出 Markdown，`format=tex` 出可编译的 LaTeX 源码（中文 ctexart / 英文 article） | `kind=paper, format=tex, title=…` |
| `qingjin_phrase` | 按「章节 × 写作意图」检索英文句式模板，附中文用途与误用提醒 | `section=intro, intent=gap` 或 `query=局限` |
| `qingjin_glossary` | 查中英术语的标准译法、其它译法与**常见误译**（收录 50+ 条，源自实读论文与 ICPC 题面） | `query=proof rate` 或 `query=混合执行` |
| `qingjin_rules` | 输出插件自己的生成规则：骨架怎么定（单一贡献、摘要六要素、CARS 三步、时态、篇幅预算）+ 中英文排版（页边距、字体字号、图表题注、参考文献）+ LaTeX 默认设置 | `scope=all` 或 `scope=typography, lang=en` |
| `qingjin_check` | 对一段文字做结构自检并打分；`section=translation` 时改为**译文校核**（数字、漏译、术语首现、长句、的/被密度、标点、比较方向） | `section=results, text=...` |

## 论文模板与 LaTeX（v0.3）

`qingjin_template` 输出的不是目录，而是**可填写的成稿模板**：每节都有【写作指令】和可直接改写的占位句，论文模板还附投稿前自查清单。

- `format=md`：Markdown 模板（论文 / 大创申报书，中英双语）
- `format=tex`：**可编译的 LaTeX 源码**。中文用 `ctexart`（xelatex 编译），英文用 `article`；含摘要、CARS 三段注释、图表环境、`thebibliography` 与填好标题/作者/日期的页首

工作台里新增两个按钮：**论文模板** 与 **LaTeX 模板**。后者会让模型生成 `.tex`、写成文件，并用 `latex_look` 真的编译一次检查版面——不是凭空说"已经好了"。

已用 xelatex 实测：模板编译通过（1 页），中文标题、作者、摘要、关键词、图表题注、参考文献段落均正常渲染。

## 右侧栏工作台（v0.2）

- 输入框右下角多了一个 **「论文」按钮**，点它直接打开右侧栏的「青衿科研」页。
- 右侧栏新增 **青衿科研** 标签页，里面是四种动作的工作台：论文骨架 / 大创申报书 / 英文句式 / 段落自检。
- 选动作、填内容，点「复制提示词」，粘贴到输入框发送，模型就会调用对应工具真正产出结果（不是静态文案）。
- 面板只做编排与复制，不联网、不读写你的文件。

> 客户端模块清单在应用启动时生成，所以首次装上或改了 `client.js` 后需要**重启 DSH**，之后照常刷新页面即可。

## 本地插件（v0.9.1）

这个包按**本地插件**设计，不通过 npm 分发：

- `package.json` 标了 `"private": true`，误发 npm 会被直接拦住；
- profile 里记录的是 `link:` 依赖，指向工作区目录 `dsh-qingjin/`，改文件即改插件；
- 安装方式：**插件页 → 添加插件 → 输入绝对路径**（或在 profile 里 `link:` 到本目录）；
- 除 `qingjin_related` 外全部离线；要**完全断网**，把环境变量设为 `QINGJIN_OFFLINE=1`，该工具会直接说明自己处于离线模式，其余 8 个工具照常工作；
- 更新：改完文件重启 DSH 即可，不涉及版本发布。

> 想恢复可发布状态：把 `package.json` 里的 `"private": true` 删掉，其余字段（name/version/exports/files）本来就能直接 `pnpm publish`。

## 精读文章：md + pdf（v0.9）

精读完一篇论文后，默认产出**两个文件，放在论文原文所在的同一个文件夹**里：

```
原文/
├─ XXX2503.10324v1.pdf        ← 你导入的原文
├─ 精读-XXX.md                ← 精读文章（Markdown 源）
└─ 精读-XXX.pdf               ← 同一份内容的 PDF
```

- 新增工具 `qingjin_export`：用 **pandoc + xelatex（ctexart，A4，页边距 2.2 cm，11 pt）** 把 .md 导出成同名 .pdf，输出目录默认取 .md 所在目录，也可用 `outDir` 指定。
- 找不到 pandoc 时它会**明确报错并给出三种替代**（装 pandoc / 用 LaTeX 编辑器编译 / 只交付 md 并说明原因），不会假装 PDF 已生成。
- 元信息（原文/作者/出处）写成**列表**而不是引用块，否则 pandoc 会把多行合并成一段。
- 面板「PDF 精读」的提示词已同步：要求把 md 存到原文同目录，再调 `qingjin_export` 出 pdf，最后回报两个路径。

## 投稿模板与四家格式（v0.8）


从 8 篇真实论文（CVPR / ECCV / AAAI / ICML）实测出来的格式表，写进 `data/rules.json`，`qingjin_rules` 可按 venue 查：

| 指标 | CVPR/ICCV | ECCV | AAAI | ICML |
|---|---|---|---|---|
| 版式 | 双栏 10 pt | LNCS 双栏 | 双栏 10 pt | PMLR 双栏 |
| 题注 | `Figure 1.` 句点 | `Fig. 1:` 冒号 | `Figure 1:` 冒号 | `Figure 1.` 句点 |
| 参考文献 | 编号 [1] | 编号 [1] | 作者-年份 | 作者-年份 |
| 摘要 | 190–230 词 | 约 180 词 | 150–200 词 | 约 200 词 |

同时记录了**八篇的共同写法**：标题多为「方法名缩写: 修饰语 for 任务」；摘要 = 问题 + However 空白 + 方法 + 数字结果 + 结论；贡献固定 3 条（数据/方法/实验）；方法 3.x 子节、先总览图后分模块；表格最加粗、次优下划线；近年普遍单设 Limitations / Broader Impact。

查询方式：

```
qingjin_rules(scope="venue", venue="cvpr")
qingjin_rules(scope="patterns")
```

面板「骨架与排版」里也加了这四家的速查一行。

## 同方向顶刊检索（v0.7，唯一联网的功能）

`qingjin_related` 从一篇论文出发，找同领域的高质量论文，并给出**可下载的链接**：

- 种子可以是**标题 / DOI / arXiv 号 / 方向关键词**
- 候选来自三条通路：`related_works`（方法相似）、双向引用（谁引它、它引谁）、以及本文主题标签下的高引工作
- 每条候选标出 **venue 等级（内置 CCF 简化表：A / B 档）**、年份、引用数、细分方向
- **预印本单独分组并标 ⚠**（arXiv / Preprints.org / DOAJ / Research Square），不会被当成顶会
- 链接优先给开放获取 PDF，其次 DOI；付费期刊请走学校图书馆
- 只把查询词发给 OpenAlex；论文全文不出本机

```
我要查这篇论文所在方向的其它高质量论文：
Large Language Model Assisted Hybrid Fuzzing
```

**等级口径**：内置表参考 CCF 推荐目录，只覆盖计算机主流方向；表里没有的 venue 显示「未收录」——那是“没收录”，不是“水平低”。要扩学科，改 [data/venues.json](data/venues.json) 即可。

**配额**：OpenAlex 免 key 时每日额度是全 IP 共享的（2026 起），频繁使用建议设置环境变量 `OPENALEX_API_KEY`（免费申请），插件会自动带上。

## 骨架与排版规则（v0.5）

工作台新增第 9 个按钮「**骨架与排版**」：点开直接列出规则，不需要输入任何内容。

- **骨架规则**：一篇一个贡献、标题即主张；摘要六要素；引言 CARS 三步；方法与结果用过去时、引言与讨论用现在时；结果一段一个陈述句小标题、段末一句结论；篇幅预算（摘要 5%/引言 15%/方法 20%/结果 30%/讨论 25%/结论 5%）。
- **中文排版**：A4、页边距上下 2.54 cm / 左右 3.17 cm；正文宋体小四 12 pt、英文 Times New Roman 12 pt、1.5 倍行距；一级黑体三号居中、二级黑体四号、三级黑体小四；图题在图下五号居中、三线表表题在表上；量与单位空一格；参考文献 GB/T 7714。
- **LaTeX 默认**：ctexart/article 11 pt、A4、2.5 cm 边距；图题在 figure 之后、表格用 booktabs、参考文献先给 thebibliography。

面板里给的是可直接照着改的要点；点「复制提示词」会让模型用 `qingjin_rules` 输出完整版（含英文排版规则与说明）。规则数据在 [data/rules.json](data/rules.json)，改那里的 JSON 就同时改了面板和工具输出。

## 术语表与译文校核（v0.4）

- `qingjin_glossary`：50+ 条中英术语，除了标准译法还给出**其它译法和常见误译**。例如 `concolic execution → 混合执行`（别译「具体执行」）、`proof rate → 证明成功率`（不是「证明率」）、`camera-ready → 终稿`（不是「相机就绪」）。条目来自实际阅读的 arXiv 论文与 ICPC 题面。
- `qingjin_check` 新增 `section=translation`：校核中文译文的**数字是否保留阿拉伯数字、是否残留整句英文、术语首现是否附英文、长句/「的」字堆叠、「被」字句、标点混用、中英间距、比较方向（at most / at least）**，并附回译检查清单。

## 文献平台可接入性（实测，2026-11）

| 平台 | 有无公开 API | 本机可达 | 结论 |
|---|---|---|---|
| OpenAlex | 有，免 key | ✅ 200 | **首选**，元数据全、无反爬 |
| Crossref | 有，免 key | ✅ 200 | DOI/题录权威，配 OpenAlex 用 |
| CORE | 有，免费 key | ✅ 200 | 全文开放获取集合，适合补全文 |
| DOAJ | 有，免 key | ✅ 200 | 开放获取期刊目录 |
| PubMed (E-utilities) | 有，免 key | ✅ 200 | 生物医学必需 |
| arXiv | 有，免 key | ✅ 200 | 预印本，抓摘要最快 |
| dblp | 有，免 key | ✅ 202 | 计算机会议/期刊题录最准 |
| Semantic Scholar | 有，key 可选 | ⚠️ 429 | 匿名有速率限制，需 key 才稳 |
| Europe PMC | 有 | ❌ 超时 | 本机网络不可用 |
| Unpaywall | 有，需邮箱 | ⚠️ 422 | 参数需合法邮箱，可重试 |
| Google Scholar | **无 API** | ❌ 超时 | 抓取违反 ToS，不做 |
| CNKI / 万方 | 无公开 API，登录+付费 | 首页 200 | 只能半自动：用户自己导出题录 |
| PubScholar | 无公开 API | 首页可达 | 同上，不做抓取 |
| Elicit | **有 REST v2 + 官方 MCP** | — | 见下 |

Elicit 采用 Bearer token（`elk_live_…`，需 Pro 及以上），并提供了官方 MCP 服务器 `https://elicit.com/api/mcp`（OAuth）。**在 DSH 里最省事的接法不是写插件，而是把它的 MCP 服务器加进 MCP 设置**，工具会自动出现。

## 设计依据（不是拍脑袋写的）

- **C-C-C（Context-Content-Conclusion）与十条法则**：Mensh & Kording (2017), *Ten simple rules for structuring papers*, PLOS Comput Biol — https://doi.org/10.1371/journal.pcbi.1005619
- **IMRaD 分节目的与时态、CARS 三步模型、结构化摘要、讨论子节**：https://imrad.se/
- **大创申报书结构**：教育部《国家级大学生创新创业训练计划管理办法》(2019) 与高校公开的项目申请书模板
- **校内选题锚点**：大连理工大学《学校简介》与网络与信息化中心公开信息（双一流学科、4 个全国重点实验室、"8+1" 学科集群、i大工 80+ 流程）

英文句式库是**自建**的模板集合（每条 3–5 个可直接改写的句子 + 中文说明 + 误用提醒）。Manchester Academic Phrasebank 是该领域最常被引用的汇编，但其站点抓取不到正文、PDF 无法稳定获取，且直接搬运涉及版权，因此这里不复制它，而是按同样的「章节 × 意图」思路自建。

## 安装

这是一个**本地插件**（`private: true`，不走 npm 分发）。两种装法：

**A. 下载后再装（推荐，不需要 git）**

1. GitHub 仓库页 → **Code → Download ZIP** → 解压到任意目录；
2. DSH → **插件页 → 添加插件** → 输入解压后目录的**绝对路径**；
3. 重启 DSH。

**B. 直接给仓库地址**（需要本机有 git，且能访问 github.com）

```
github:wocao123103/dsh-qingjin
```

零依赖、零构建，安装时不会触发任何 build 脚本确认。完整上传与自检清单见 [GITHUB-UPLOAD.md](GITHUB-UPLOAD.md)。

## 使用示例

```
帮我列一篇关于「基于视觉的船舶焊缝缺陷检测」的论文骨架，目标 5000 词
```

```
给我几句指出研究空白的英文，用在引言第三段
```

```
帮我检查这段结果段（粘贴）——总觉得最后一句不像结论
```

```
我要写大创申报书，方向是海洋工程，先给我骨架
```

## 边界（重要）

- **不代写论文**：只产出骨架、表述选项与诊断。学术诚信是硬约束。
- **不联网、不读你的文件**：数据随包打包，工具是纯函数，只处理你贴进来的文本。
- **不含文献检索与引用格式生成**（v0.1 范围外）。
- 自检是**启发式规则**，不是学术判断：分数低不等于论文差，只说明这些可自动检查的项需要看一眼。
- 大创相关事实随学校政策变动，申报前务必以本校当年通知为准。

## 数据文件

| 文件 | 内容 |
|---|---|
| `data/structure.json` | 研究论文与大创申报书的章节结构、时态、篇幅预算、结构动作、自查项 |
| `data/phrases.json` | 英文句式库（8 个章节、38 组意图） |
| `data/dut.json` | 凌水主校区的公开事实与选题锚点 |

## 开发

纯 ESM、零依赖、零构建。修改 `index.js` 或 `data/*.json` 后重启 DSH 即可生效。

## 许可

MIT
